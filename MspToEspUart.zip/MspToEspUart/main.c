#include <msp430f5529.h>

#define M1FORWARD BIT0
#define M2FORWARD BIT2
#define M1REVERSE BIT3
#define M2REVERSE BIT4
#define PWM BIT2
#define TXD BIT4
#define RXD BIT3
#define S 0
#define F 1
#define R 2
#define L 3
#define B 4


void direction (int val) //direction control function
{
    switch (val)
    {
    case S: //stop
        P2OUT =0x00;
        break;
    case F: //forward
        P2OUT = M1FORWARD + M2FORWARD;
        break;
    case R: //right
        P2OUT = M1FORWARD + M2REVERSE;
        break;
    case L: //left;
        P2OUT = M2FORWARD + M1REVERSE;
        break;
    case B: //reverse
        P2OUT = M1REVERSE + M2REVERSE;
        break;
    }
}

unsigned int i;
void main(void)
{
    WDTCTL = WDTPW | WDTHOLD;               // Stop watchdog timer

    //PWM setup
    TA0CTL = TASSEL_2 + MC_1;               //sets counting mode (upcount)
    TA0CCR0 = 10000;                        //sets PWM period
    TA0CCR1 = 2000;                         //sets PWM duty cycle
    TA0CCTL1 = OUTMOD_7;                    //decides to reset when TA0CCR1 valued is reached
    P1SEL |= PWM;                           //set TIMERA to PWM pin

    P1DIR |=PWM;                            //PWM is output
    P2DIR |= 0xFF;                          //set PORT2 as OUTPUT
    P2OUT &= 0x00;                          //initialize PORT2 to 0

    P3SEL |= RXD + TXD ;                    //set 3.3 and 3.4 to RX and TX for UART
    UCA0CTL1 |= UCSSEL_2;                   //select SMCLK 1MHz
    UCA0BR0 = 0x08;                         //prescalar for 115200
    UCA0BR1 = 0x00;
    UCA0MCTL = UCBRS2 + UCBRS1;             // Modulation UCBRSx = 6
    UCA0CTL1 &= ~UCSWRST;                   // **Initialize USCI state machine**
    UCA0IE = UCRXIE;
    __bis_SR_register(GIE);                 //enable global interrupts

    while (1)
       {

       }
}

#pragma vector = USCI_A0_VECTOR
__interrupt void USCI_A0_ISR(void) {
switch(__even_in_range(UCA0IV,18)) {
case 0x00:                                  // Vector 0: No interrupts
break;
case 0x02:                                  // Vector 2: UCRXIFG
    if (UCA0RXBUF == 'f')
    {
        direction(F);
    }
    else if (UCA0RXBUF == 'b')
    {
        direction(B);
    }
    else if (UCA0RXBUF == 'r')
    {
        direction(R);
    }
    else if (UCA0RXBUF == 'l')
    {
        direction(L);
    }
    else if (UCA0RXBUF == 's')
    {
        direction(S);
    }
    UCA0IE = UCRXIE;
    UCA0IFG &= ~UCRXIFG;
break;
case 0x04:                                  // Vector 4: UCTXIFG
break;
case 0x06:                                  // Vector 6: UCSTTIFG
break;
case 0x08:                                  // Vector 8: UCTXCPTIFG
break;
default: break;
}
}

